/**
 * Documents Page
 *
 * Searchable grid layout of document cards with title, creation date,
 * status badge, and download button. Includes loading, empty, and error states.
 */

'use client';

import { Suspense, useState, useMemo, useCallback } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  FileText,
  Search,
  Download,
  RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { CardPageHeader } from '@/components/common/card-page-header';
import { StatusBadge } from '@/components/common/status-badge';
import { EmptyState } from '@/components/common/empty-state';
import { CardSkeleton } from '@/components/common/loading-skeleton';
import { ErrorBanner } from '@/components/common/error-banner';
import { useDocuments } from '@/hooks/use-documents';
import { useTranslation } from '@/providers/i18n-provider';

/* -------------------------------------------------------------------------- */
/*  Types                                                                      */
/* -------------------------------------------------------------------------- */

type DocumentStatus = 'published' | 'draft' | 'archived' | 'processing';

interface Document {
  id: string;
  title: string;
  status: DocumentStatus;
  createdAt: string;
  downloadUrl: string;
  fileSize?: number;
  mimeType?: string;
}

/* -------------------------------------------------------------------------- */
/*  Status → StatusBadge variant mapping                                       */
/* -------------------------------------------------------------------------- */

const statusVariantMap: Record<DocumentStatus, 'success' | 'warning' | 'info' | 'pending'> = {
  published: 'success',
  draft: 'warning',
  archived: 'info',
  processing: 'pending',
};

/* -------------------------------------------------------------------------- */
/*  Helpers                                                                    */
/* -------------------------------------------------------------------------- */

function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(iso));
}

function formatFileSize(bytes?: number): string | null {
  if (bytes == null) return null;
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/* -------------------------------------------------------------------------- */
/*  Document Card                                                              */
/* -------------------------------------------------------------------------- */

interface DocumentCardProps {
  document: Document;
  onDownload: (doc: Document) => void;
}

function DocumentCard({ document, onDownload }: DocumentCardProps) {
  const { t } = useTranslation();
  const sizeLabel = formatFileSize(document.fileSize);

  return (
    <Card className="flex flex-col justify-between transition-shadow hover:shadow-md">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
            <CardTitle className="truncate text-sm font-semibold">
              {document.title}
            </CardTitle>
          </div>
          <StatusBadge
            status={document.status}
            variant={statusVariantMap[document.status]}
          />
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        <div className="space-y-1 text-xs text-muted-foreground">
          <p>Created {formatDate(document.createdAt)}</p>
          {sizeLabel && <p>{sizeLabel}</p>}
        </div>
      </CardContent>

      <CardFooter className="pt-0">
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={() => onDownload(document)}
        >
          <Download className="mr-2 h-3.5 w-3.5" />
          {t.common?.download ?? 'Download'}
        </Button>
      </CardFooter>
    </Card>
  );
}

/* -------------------------------------------------------------------------- */
/*  Loading skeleton grid                                                      */
/* -------------------------------------------------------------------------- */

function DocumentGridSkeleton() {
  return (
    <div className="grid gap-4 grid-cols-[repeat(auto-fill,minmax(280px,1fr))]">
      {Array.from({ length: 6 }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Page (entry point with Suspense boundary)                                  */
/* -------------------------------------------------------------------------- */

export default function DocumentsPage() {
  return (
    <Suspense fallback={null}>
      <DocumentsContent />
    </Suspense>
  );
}

/* -------------------------------------------------------------------------- */
/*  Page content                                                               */
/* -------------------------------------------------------------------------- */

function DocumentsContent() {
  const { t } = useTranslation();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [searchText, setSearchText] = useState('');

  const currentPath = searchParams.get('path') || '/';

  const {
    data: rawDocuments = [],
    isLoading,
    error,
    refetch,
  } = useDocuments(currentPath);

  /* ---- Filter documents by search text ---- */
  const documents: Document[] = useMemo(() => {
    const docs = (rawDocuments as Document[]) || [];
    if (!searchText) return docs;
    const q = searchText.toLowerCase();
    return docs.filter(
      (doc) =>
        doc.title.toLowerCase().includes(q) ||
        doc.status.toLowerCase().includes(q),
    );
  }, [rawDocuments, searchText]);

  /* ---- Download handler ---- */
  const handleDownload = useCallback((doc: Document) => {
    const link = document.createElement('a');
    link.href = doc.downloadUrl;
    link.download = doc.title;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  /* ---- Header ---- */
  const headerActions = (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search documents..."
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="pl-8 w-[220px]"
        />
      </div>
    </div>
  );

  const header = (
    <CardPageHeader
      icon={FileText}
      title={t.documentsPage?.title ?? 'Documents'}
      description={t.documentsPage?.description ?? 'Browse and download documents'}
      actions={headerActions}
    />
  );

  /* ---- Loading state ---- */
  if (isLoading) {
    return (
      <div className="space-y-6">
        {header}
        <DocumentGridSkeleton />
      </div>
    );
  }

  /* ---- Error state ---- */
  if (error) {
    return (
      <div className="space-y-6">
        {header}
        <ErrorBanner
          message={
            error instanceof Error
              ? error.message
              : 'Failed to load documents. Please try again.'
          }
          onRetry={() => refetch()}
        />
      </div>
    );
  }

  /* ---- Empty state ---- */
  if (documents.length === 0 && !searchText) {
    return (
      <div className="space-y-6">
        {header}
        <EmptyState
          icon={FileText}
          title="No documents found"
          description="There are no documents available yet. Documents will appear here once they are uploaded."
        />
      </div>
    );
  }

  /* ---- No search results ---- */
  if (documents.length === 0 && searchText) {
    return (
      <div className="space-y-6">
        {header}
        <EmptyState
          icon={Search}
          title="No matching documents"
          description={`No documents match "${searchText}". Try adjusting your search terms.`}
          actionLabel="Clear search"
          onAction={() => setSearchText('')}
        />
      </div>
    );
  }

  /* ---- Grid view ---- */
  return (
    <div className="space-y-6">
      {header}

      <p className="text-sm text-muted-foreground">
        {documents.length} document{documents.length !== 1 ? 's' : ''}
      </p>

      <div className="grid gap-4 grid-cols-[repeat(auto-fill,minmax(280px,1fr))]">
        {documents.map((doc) => (
          <DocumentCard
            key={doc.id}
            document={doc}
            onDownload={handleDownload}
          />
        ))}
      </div>
    </div>
  );
}
