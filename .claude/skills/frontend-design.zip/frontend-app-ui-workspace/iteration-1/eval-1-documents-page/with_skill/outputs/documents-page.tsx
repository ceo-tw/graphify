'use client';

import { useState, useMemo, useCallback } from 'react';
import { FileText, Search, Download, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/common/page-header';
import { EmptyState } from '@/components/common/empty-state';
import { StatusBadge } from '@/components/common/status-badge';
import { CardSkeleton } from '@/components/common/loading-skeleton';
import { useTranslation } from '@/providers/i18n-provider';
import { useDocuments } from '@/hooks/use-documents';

/**
 * Document status to StatusBadge variant mapping.
 */
const STATUS_VARIANT_MAP: Record<string, 'success' | 'warning' | 'info' | 'error'> = {
  published: 'success',
  draft: 'warning',
  archived: 'info',
  error: 'error',
};

/**
 * Formats an ISO date string to a localized short date.
 */
function formatDate(dateStr: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(new Date(dateStr));
  } catch {
    return dateStr;
  }
}

/**
 * Document type from the API response.
 */
interface Document {
  id: string;
  title: string;
  status: string;
  createdAt: string;
  downloadUrl?: string;
  fileSize?: number;
  mimeType?: string;
}

/**
 * Individual document card component.
 *
 * Displays document title, creation date, status badge, and a download button.
 * Card is interactive per the design philosophy: each card has a clear action (download).
 */
function DocumentCard({ document }: { document: Document }) {
  const { t } = useTranslation();
  const variant = STATUS_VARIANT_MAP[document.status] || 'info';

  const handleDownload = useCallback(() => {
    if (!document.downloadUrl) return;
    const a = window.document.createElement('a');
    a.href = document.downloadUrl;
    a.download = document.title;
    window.document.body.appendChild(a);
    a.click();
    window.document.body.removeChild(a);
  }, [document.downloadUrl, document.title]);

  return (
    <Card className="group transition-colors hover:border-primary/30">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <CardTitle className="text-sm truncate">{document.title}</CardTitle>
          </div>
          <StatusBadge status={document.status} variant={variant} />
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {formatDate(document.createdAt)}
          </span>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleDownload}
            disabled={!document.downloadUrl}
            className="opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Download className="h-4 w-4 mr-1" />
            {t.common.download}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

/**
 * Loading skeleton matching the documents grid layout.
 *
 * Renders page header skeleton and a grid of card skeletons to match
 * the actual page structure.
 */
function DocumentsLoadingSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="h-8 w-[200px] bg-muted animate-pulse rounded" />
        <div className="h-4 w-[300px] bg-muted animate-pulse rounded" />
      </div>
      <div className="grid gap-4 grid-cols-[repeat(auto-fill,minmax(300px,1fr))]">
        {Array.from({ length: 6 }).map((_, i) => (
          <CardSkeleton key={i} />
        ))}
      </div>
    </div>
  );
}

/**
 * Documents list page.
 *
 * Displays a searchable grid of document cards. Each card shows the document title,
 * creation date, status badge, and a download button. Includes proper handling for
 * loading, empty, and error states.
 *
 * Architecture:
 * - Uses PageHeader for consistent page layout
 * - Auto-fill responsive grid (min 300px per card)
 * - Client-side search filtering on title
 * - StatusBadge with semantic color mapping for document statuses
 * - EmptyState component for zero-result states
 */
export default function DocumentsPage() {
  const { t } = useTranslation();
  const [searchText, setSearchText] = useState('');

  const { data, isLoading, error, refetch } = useDocuments();

  const documents: Document[] = useMemo(() => {
    const items = data?.data ?? [];
    if (!searchText) return items;
    const query = searchText.toLowerCase();
    return items.filter((doc: Document) =>
      doc.title.toLowerCase().includes(query)
    );
  }, [data, searchText]);

  // -- Loading state --
  if (isLoading) {
    return <DocumentsLoadingSkeleton />;
  }

  // -- Error state --
  if (error) {
    return (
      <div className="space-y-6">
        <PageHeader
          title={t.pages.documents.title}
          description={t.pages.documents.description}
        />
        <div className="flex flex-col items-center gap-4 py-12 text-center">
          <p className="text-destructive text-sm">
            {t.pages.documents.errorLoading(error.message)}
          </p>
          <Button variant="outline" size="sm" onClick={() => refetch()}>
            <RefreshCw className="mr-2 h-4 w-4" />
            {t.common.retry}
          </Button>
        </div>
      </div>
    );
  }

  // -- Header with search --
  const headerActions = (
    <div className="flex items-center gap-2">
      <div className="relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder={t.pages.documents.searchPlaceholder}
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          className="pl-8 w-[220px]"
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title={t.pages.documents.title}
        description={t.pages.documents.description}
        actions={headerActions}
      />

      {/* Empty state */}
      {documents.length === 0 ? (
        <EmptyState
          icon={FileText}
          title={
            searchText
              ? t.pages.documents.noSearchResults
              : t.pages.documents.noDocuments
          }
          description={
            searchText
              ? t.pages.documents.noSearchResultsDescription
              : t.pages.documents.noDocumentsDescription
          }
        />
      ) : (
        /* Document grid -- auto-fill responsive layout */
        <div className="grid gap-4 grid-cols-[repeat(auto-fill,minmax(300px,1fr))]">
          {documents.map((doc) => (
            <DocumentCard key={doc.id} document={doc} />
          ))}
        </div>
      )}
    </div>
  );
}
