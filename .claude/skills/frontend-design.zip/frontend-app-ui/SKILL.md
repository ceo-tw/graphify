---
name: frontend-app-ui
type: capability
description: "App UI implementation guide. Use when: (1) building a new portal page, (2) modifying existing page UI, (3) needing design token usage guidance. Invoke with /frontend-app-ui."
allowed-tools:
  - Read
  - Grep
  - Glob
user-invocable: true
---

# Frontend App UI

Design guide for app UI implementation. Focused on concrete Tailwind classes and JSX patterns.

---

## 1. Design Philosophy

- **Calm surface hierarchy**: Place `bg-card` surfaces on top of `bg-background`
- **Minimal chrome**: Sidebar borderless, cards use `1px solid border` only (no box-shadow)
- **Single accent**: Use `bg-primary` (#FF4D4D) as the only accent color
- **Cards only when interactive**: Cards only for clickable/expandable content. No decorative containers
- **Product copy**: No marketing language. Focus on Orientation (where am I) / Status (what's happening) / Action (what can I do)

---

## 2. Token Mapping (Essentials)

| Purpose | Tailwind Class | Light | Dark |
|---------|---------------|-------|------|
| Page background | `bg-background` | #F7F5F0 | #000000 |
| Card surface | `bg-card` | #FFFFFF | #181818 |
| Content area | `bg-content-area` | #FFFFFF | #181818 |
| Primary text | `text-foreground` | #1B1B1B | #FFFFFFE6 |
| Secondary text | `text-muted-foreground` | #000000CC | #FFFFFF80 |
| Accent | `text-primary` / `bg-primary` | #FF4D4D | #FF4D4D |
| Accent text | `text-primary-foreground` | #FFFFFF | #FFFFFF |
| Border | `border-border` | #EEEEEE | #333333 |
| Input bg | `bg-input` | #0000001A | #FFFFFF26 |
| Success | `text-success` | #00A86B | #00BA6C |
| Warning | `text-warning` | #C4A000 | #D4B000 |
| Destructive | `text-destructive` | #0099A0 | #50D3C4 |
| Info | `text-info` | #007ACC | #4D9FE6 |
| Hover | `hover:bg-accent` | #0000000D | #FFFFFF1A |

**No hardcoding**: Use `bg-primary` not `bg-[#FF4D4D]`, `text-muted-foreground` not `text-gray-500`

---

## 3. Page Architecture Patterns

### List Page

```tsx
<div className="space-y-6">
  <PageHeader
    title={t.pages.feature.title}
    description={t.pages.feature.description}
    actions={
      <div className="flex items-center gap-2">
        <SearchInput />
        <Button><Plus className="mr-2 h-4 w-4" />{t.common.create}</Button>
      </div>
    }
  />
  {/* Grid layout */}
  <div className="grid gap-4 grid-cols-[repeat(auto-fill,minmax(300px,1fr))]">
    {items.map(item => <ItemCard key={item.id} {...item} />)}
  </div>
  {/* Or table layout */}
  <DataTable columns={columns} data={items} />
</div>
```

### Detail Page

```tsx
<div className="space-y-6">
  <PageHeader title={item.name} actions={<ActionButtons />} />
  <Tabs defaultValue="overview">
    <TabsList>
      <TabsTrigger value="overview">{t.common.overview}</TabsTrigger>
      <TabsTrigger value="settings">{t.common.settings}</TabsTrigger>
    </TabsList>
    <TabsContent value="overview">...</TabsContent>
    <TabsContent value="settings">...</TabsContent>
  </Tabs>
</div>
```

### Form Page

```tsx
<div className="space-y-6">
  <PageHeader title={t.pages.feature.create} />
  <Card>
    <CardContent className="pt-6">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField control={form.control} name="name" render={({field}) => (
            <FormItem>
              <FormLabel>{t.common.name}</FormLabel>
              <FormControl><Input {...field} /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <LoadingButton type="submit" loading={isPending}>{t.common.save}</LoadingButton>
        </form>
      </Form>
    </CardContent>
  </Card>
</div>
```

### Dashboard

```tsx
<div className="space-y-6">
  <CardPageHeader icon={LayoutDashboard} title={t.pages.dashboard.title} />
  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
    {kpiCards.map(kpi => <KpiCard key={kpi.id} {...kpi} />)}
  </div>
  <div className="grid gap-4 md:grid-cols-2">
    <ChartWidget /><TableWidget />
  </div>
</div>
```

---

## 4. State Handling

| State | Component | Pattern |
|-------|-----------|---------|
| Loading | `PageSkeleton`, `CardSkeleton`, `TableSkeleton` | Skeleton matching actual layout |
| Error | Inline error + retry | `<Alert variant="destructive">` + `<Button onClick={refetch}>` |
| Empty | `EmptyState` | icon + title + description + action button |
| Data | Actual components | Normal data rendering |

```tsx
if (isLoading) return <PageSkeleton />
if (error) return <Alert variant="destructive"><AlertDescription>{error.message}<Button onClick={refetch}>Retry</Button></AlertDescription></Alert>
if (!data?.length) return <EmptyState icon={FileX} title={t.common.noData} action={<Button>...</Button>} />
return <DataTable columns={columns} data={data} />
```

---

## 5. i18n Pattern

```tsx
const { t } = useTranslation()
// Usage: t.pages.agents.title, t.common.create, t.common.save
// All user-facing strings MUST go through t.*
```

---

## 6. Responsive Patterns

| Pattern | Classes |
|---------|---------|
| Header | `flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between` |
| Auto-fill grid | `grid gap-4 grid-cols-[repeat(auto-fill,minmax(300px,1fr))]` |
| 2/3-col grid | `grid gap-4 md:grid-cols-2 lg:grid-cols-3` |
| KPI 4-col | `grid gap-4 md:grid-cols-2 lg:grid-cols-4` |

---

## 7. Rules

1. **ZERO hardcoded colors** -- token classes only
2. **All strings via i18n** -- `useTranslation()` throughout
3. **'use client'** -- only when hooks/interactivity needed
4. **Suspense** -- required when using `useSearchParams()`
5. **Dark mode** -- verify every `bg-*` has `.dark` token counterpart
6. **MotionPreset** -- use for animations instead of raw `motion.div`
7. **Reuse components** -- check existing common/ components before creating new ones

---

## 8. Litmus Checks

1. Is the single focus of this viewport clear?
2. Is the accent color (primary) used sparingly?
3. Does every card serve an interactive purpose?
4. Is there unnecessary chrome (border, shadow, decoration)?
5. Do status colors use semantic tokens (success/warning/destructive)?
6. Can the page be understood by scanning headings, labels, and numbers alone?
7. Does the design look premium with all decorative elements removed?
