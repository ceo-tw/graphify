---
name: frontend-design-analyzer
type: capability
description: "Analyze project design system automatically. Use when: (1) assessing a project's design system, (2) extracting and organizing design tokens, (3) making design decisions. Invoke with /frontend-design-analyzer."
allowed-tools:
  - Read
  - Grep
  - Glob
  - AskUserQuestion
user-invocable: true
---

# Frontend Design Analyzer

Automatically scan project files to extract the design system, then ask the user to make decisions on missing information. After completion, connect to `frontend-app-ui` skill for implementation guidance.

---

## Step 1: Project Auto-Scan

Read files in this order to extract design system information.

### 1-A. CSS Variables (globals.css)

```
Glob(pattern="**/globals.css", path="{project_root}/src/")
Read(file_path="{found_path}")
```

Extract:
- `--background`, `--foreground`, `--card`, `--primary`, `--muted`, `--accent`, `--destructive`, `--border`, `--input`, `--ring` (both `:root` and `.dark`)
- `--radius`, `--font-*`, `--shadow-*`
- Status tokens: `--status-*`, `--chart-*`, `--sidebar-*`

### 1-B. shadcn Config (components.json)

```
Read(file_path="{project_root}/src/admin-portal/components.json")
```

Extract:
- `style` (new-york / default)
- `tailwind.baseColor`
- `aliases` (components, utils, ui, lib, hooks paths)

### 1-C. Core Dependencies (package.json)

```
Read(file_path="{project_root}/src/admin-portal/package.json")
```

Extract (with versions if present):
- `tailwindcss`, `@tailwindcss/vite`
- `motion` (Framer Motion v7+)
- `recharts`
- `@tanstack/react-table`, `@tanstack/react-query`
- `react-hook-form`, `zod`
- `lucide-react`
- `next`

### 1-D. Component Pattern Docs

```
Glob(pattern="**/README.md", path="{project_root}/src/admin-portal/components/")
```

Read each README.md to collect component lists and usage patterns.

---

## Step 2: Analysis Report

After scanning, output a structured report:

```
=== Design System Analysis ===

[Color System]
- Primary:     #FF4D4D (same light/dark)
- Background:  #F7F5F0 / #000000
- Card:        #FFFFFF / #181818
- Border:      #EEEEEE / #333333
- Success:     #00A86B / #00BA6C
- Warning:     #C4A000 / #D4B000
- Info:        #007ACC / #4D9FE6
- Destructive: #0099A0 / #50D3C4

[Typography]
- Sans:  Geist (weight 100-900)
- Mono:  Geist Mono
- Serif: Georgia

[Layout]
- Radius: 0.375rem
- Shadow: warm-tinted (light), neutral (dark)

[Component Library]
- shadcn/ui: new-york style (Radix UI based)
- Lucide React (icons)
- 40+ ui/ primitives

[Animation]
- motion (Framer Motion v7) -- MotionPreset wrapper component available

[Data]
- TanStack Table v8, TanStack Query v5
- Recharts v2 (chart/ wrapper components available)

[Forms]
- react-hook-form + zod
```

---

## Step 3: Decision Collection

For items that cannot be determined by scanning, present options via AskUserQuestion. Ask one at a time.

### 3-A. Brand Tone

```
AskUserQuestion(
  question="Select the brand tone for this project.",
  options=[
    { label: "Professional", description: "Trust, clear hierarchy, restrained colors" },
    { label: "Technical",    description: "High data density, monospace accents" },
    { label: "Playful",      description: "Rounded corners, vibrant accent" },
    { label: "Editorial",    description: "Typography-driven, serif usage, generous whitespace" }
  ]
)
```

### 3-B. Information Density

```
AskUserQuestion(
  question="Select the information density approach.",
  options=[
    { label: "Minimal chrome",    description: "Essentials only, no unnecessary decoration" },
    { label: "Information dense",  description: "Max info per screen, table/grid-centric" },
    { label: "Spacious",           description: "Generous whitespace, card-centric layout" }
  ]
)
```

### 3-C. Card Usage Policy

```
AskUserQuestion(
  question="Select the Card component usage policy.",
  options=[
    { label: "Interactive only",  description: "Cards only when clickable/actionable" },
    { label: "Grouping allowed",  description: "Cards also for grouping related info" },
    { label: "Free use",          description: "Cards freely for layout purposes" }
  ]
)
```

### 3-D. Color Strategy

```
AskUserQuestion(
  question="Select the accent color strategy.",
  options=[
    { label: "Single accent strict",    description: "Only primary (#FF4D4D) as accent" },
    { label: "Contextual multi-accent", description: "Allow semantic colors per status/function" }
  ]
)
```

---

## Step 4: Post-Decision Guidance

After all decisions are confirmed, output:

```
=== Design Decisions Confirmed ===

Brand tone:       {selection}
Info density:     {selection}
Card policy:      {selection}
Color strategy:   {selection}

Analysis complete. To start UI implementation, use /frontend-app-ui.
For token reference, load /frontend-design-system.
```

---

## Notes

- If globals.css is not found, use Grep to search for `--primary` pattern to locate CSS files.
- For component directories without README.md, collect file listing via Glob.
- If scan results conflict with user decisions, user choice takes priority.
