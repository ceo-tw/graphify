---
name: frontend-design-system
type: library
description: "Admin-portal design system reference. Provides CSS variables, Tailwind class mappings, and component catalog."
user-invocable: false
---

# Frontend Design System

Design tokens and component catalog for the admin-portal. Referenced by other skills.

---

## 1. CSS Variable -> Tailwind Class Mapping

### Core

| CSS Variable | Tailwind | Light | Dark |
|-------------|----------|-------|------|
| `--background` | `bg-background` | #F7F5F0 | #000000 |
| `--foreground` | `text-foreground` | #1B1B1B | #FFFFFFE6 |
| `--card` | `bg-card` | #FFFFFF | #181818 |
| `--card-foreground` | `text-card-foreground` | #1B1B1B | #F8F8F8 |
| `--content-area` | `bg-content-area` | #FFFFFF | #181818 |
| `--popover` | `bg-popover` | #F7F5F0 | #000000 |
| `--primary` | `bg-primary` / `text-primary` | #FF4D4D | #FF4D4D |
| `--primary-foreground` | `text-primary-foreground` | #FFFFFF | #FFFFFF |
| `--secondary` | `bg-secondary` | #FFFFFF | #000000 |
| `--secondary-foreground` | `text-secondary-foreground` | #FF4D4D | #FFFFFFCC |
| `--muted` | `bg-muted` | #0000000D | #000000CC |
| `--muted-foreground` | `text-muted-foreground` | #000000CC | #FFFFFF80 |
| `--accent` | `bg-accent` | #0000000D | #FFFFFF1A |
| `--accent-foreground` | `text-accent-foreground` | #1B1B1B | #FFFFFF |
| `--destructive` | `bg-destructive` / `text-destructive` | #0099A0 | #50D3C4 |
| `--border` | `border-border` | #EEEEEE | #333333 |
| `--input` | `bg-input` | #0000001A | #FFFFFF26 |
| `--ring` | `ring-ring` | #00000033 | #FFFFFF80 |

### Status

| CSS Variable | Usage | Light | Dark |
|-------------|-------|-------|------|
| `--status-running` | `text-[var(--status-running)]` | #00A86B | #00BA6C |
| `--status-running-bg` | `bg-[var(--status-running-bg)]` | #E6F7F0 | #1A4D33 |
| `--status-stopped` | `text-[var(--status-stopped)]` | #A73000 | #C65D00 |
| `--status-error` | `text-[var(--status-error)]` | #A73000 | #C65D00 |
| `--status-awaiting` | `text-[var(--status-awaiting)]` | #B39500 | #C2A100 |
| `--status-inactive` | `text-[var(--status-inactive)]` | #8C8C8C | #6B7280 |

### Semantic Colors

| CSS Variable | Tailwind | Light | Dark |
|-------------|----------|-------|------|
| `--success` | `text-success` / `bg-success` | #00A86B | #00BA6C |
| `--warning` | `text-warning` / `bg-warning` | #C4A000 | #D4B000 |
| `--info` | `text-info` / `bg-info` | #007ACC | #4D9FE6 |
| `--trend-up` | `text-trend-up` | #00A86B | #00BA6C |
| `--trend-down` | `text-trend-down` | #A73000 | #C65D00 |

### Chart (oklch)

| CSS Variable | Light | Dark |
|-------------|-------|------|
| `--chart-1` | oklch(0.67 0.171 25) | oklch(0.47 0.15 25) |
| `--chart-2` | oklch(0.57 0.182 25) | oklch(0.57 0.182 25) |
| `--chart-3` | oklch(0.47 0.15 25) | oklch(0.67 0.171 25) |
| `--chart-4` | oklch(0.37 0.118 25) | oklch(0.77 0.107 25) |
| `--chart-5` | oklch(0.27 0.086 25) | oklch(0.87 0.055 25) |

### Sidebar

| CSS Variable | Tailwind | Light | Dark |
|-------------|----------|-------|------|
| `--sidebar` | `bg-sidebar` | #F7F5F0 | #000000 |
| `--sidebar-foreground` | `text-sidebar-foreground` | #1B1B1BCC | #FFFFFFCC |
| `--sidebar-primary` | `bg-sidebar-primary` | #FF4D4D | #FF4D4D |
| `--sidebar-border` | `border-sidebar-border` | transparent | transparent |

### Avatar

| Role | CSS Variable | Light | Dark |
|------|-------------|-------|------|
| Default | `--avatar-default` | #FF4D4D | #FF4D4D |
| CEO | `--avatar-ceo` | #4F46E5 | #6366F1 |
| CTO | `--avatar-cto` | #7C3AED | #8B5CF6 |
| PM | `--avatar-pm` | #0891B2 | #06B6D4 |
| Dev | `--avatar-dev` | #059669 | #10B981 |
| QA | `--avatar-qa` | #D97706 | #F59E0B |

---

## 2. Typography

| Variable | Font Family | Purpose |
|----------|------------|---------|
| `--font-sans` | Geist (100-900) | Default body, UI |
| `--font-mono` | Geist Mono (100-900) | Code, monospace |
| `--font-serif` | Georgia, Times New Roman | Editorial emphasis |

---

## 3. Layout Tokens

| Token | Value |
|-------|-------|
| `--radius` (base) | 0.375rem |
| `--radius-sm` | base - 4px |
| `--radius-md` | base - 2px |
| `--radius-lg` | base |
| `--radius-xl` | base + 4px |

**Shadow**: 8 levels (2xs to 2xl)
- Light: warm-tinted `rgba(70, 48, 42, opacity)`
- Dark: neutral `rgba(0, 0, 0, opacity)`

**Card**: `border: 1px solid var(--border)`, `box-shadow: none`
**Sidebar**: `border: transparent` (borderless)

---

## 4. Component Catalog

### ui/ (40+ primitives)
Button, Card, Dialog, DropdownMenu, Tabs, Input, Form, Select, Checkbox, RadioGroup, Switch, Tooltip, Popover, Sheet, Alert, Badge, Avatar, Separator, ScrollArea, Textarea, Label, Table, Skeleton, Progress, Calendar, Command, NavigationMenu, MotionPreset

### common/
PageHeader, CardPageHeader, DataTable, EmptyState, StatusBadge, ProfileWidget, EditableProfileWidget, LoadingButton, ConfirmDialog, LoadingSkeleton (Page/Card/Table/List variants)

### chart/
AreaChart, BarChart, DonutChart, LineChart, HeatmapChart, RadialChart, StackedBarChart, ComposedChart, PieChart, RadarChart, TrendBadge, BaseCalendarHeatmap

### layout/
AdminSidebar, UnifiedSidebar, SiteHeader, SiteFooter, CommandPalette, ModeToggle, NotificationBell

### Feature-specific
agents/, billing/, dashboard/, analytics/, chat/, onboarding/, settings/, organizations/, etc. (32 categories)

---

## 5. Anti-Patterns

- `bg-[#FF4D4D]` -> use `bg-primary`
- `text-gray-500` -> use `text-muted-foreground`
- `font-family: Arial` -> Geist only
- Adding border to sidebar (intentionally borderless)
- Adding box-shadow to cards (1px border only)
- `bg-white` / `bg-black` -> use `bg-background` / `bg-card`
