"use client";

import Image from "next/image";
import Link from "next/link";
import { Check } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

/* ---------------------------------------------------------------------------
 * Data
 * --------------------------------------------------------------------------- */

const features = [
  {
    title: "Deploy Agents in Minutes",
    desc: "Define your agent's personality, knowledge base, and capabilities through an intuitive builder. No infrastructure management required -- ClawPod handles scaling, monitoring, and orchestration automatically.",
    image: "/images/landing/feature-deploy.png",
  },
  {
    title: "Real-Time Observability",
    desc: "Monitor every conversation, tool call, and decision your agents make with a live operations dashboard. Trace issues to their root cause and iterate on agent behavior with confidence.",
    image: "/images/landing/feature-observability.png",
  },
  {
    title: "Enterprise-Grade Security",
    desc: "Run agents inside your own VPC with end-to-end encryption, SOC 2 compliance, and granular role-based access controls. Your data never leaves your environment.",
    image: "/images/landing/feature-security.png",
  },
];

const plans = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "For individuals exploring AI agents",
    recommended: false,
    cta: "Get started",
    features: [
      "1 agent",
      "1,000 messages / month",
      "Community support",
      "Basic analytics",
      "Shared infrastructure",
    ],
  },
  {
    name: "Pro",
    price: "$49",
    period: "/ month",
    description: "For teams shipping AI-powered products",
    recommended: true,
    cta: "Start free trial",
    features: [
      "Unlimited agents",
      "50,000 messages / month",
      "Priority support",
      "Advanced analytics & tracing",
      "Custom knowledge bases",
      "Webhook integrations",
    ],
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    description: "For organizations with strict compliance needs",
    recommended: false,
    cta: "Contact sales",
    features: [
      "Everything in Pro",
      "Unlimited messages",
      "Dedicated infrastructure",
      "SSO & SAML",
      "SLA & uptime guarantee",
      "VPC deployment",
      "Dedicated account manager",
    ],
  },
];

/* ---------------------------------------------------------------------------
 * Component
 * --------------------------------------------------------------------------- */

export default function LandingPage() {
  return (
    <div className="min-h-svh bg-background text-foreground">
      {/* ------------------------------------------------------------------ */}
      {/* Header                                                             */}
      {/* ------------------------------------------------------------------ */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <Link href="/" className="text-xl font-bold tracking-tight">
            ClawPod
          </Link>
          <nav className="hidden items-center gap-8 md:flex">
            <a
              href="#features"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Features
            </a>
            <a
              href="#pricing"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Pricing
            </a>
            <Link href="/docs" className="text-sm text-muted-foreground transition-colors hover:text-foreground">
              Docs
            </Link>
          </nav>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" asChild>
              <Link href="/login">Sign in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/signup">Get started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* ------------------------------------------------------------------ */}
      {/* Hero -- Product Hero pattern (screenshot + headline)               */}
      {/* ------------------------------------------------------------------ */}
      <section className="relative flex min-h-[calc(100svh-4rem)] items-center">
        <div className="container mx-auto grid items-center gap-12 px-4 lg:grid-cols-2">
          <div>
            <h1 className="text-4xl font-bold tracking-tight md:text-6xl">
              Build AI agents that actually work
            </h1>
            <p className="mt-6 text-lg text-muted-foreground">
              ClawPod gives your team the platform to create, deploy, and
              operate production-ready AI agents -- from prototype to scale.
            </p>
            <div className="mt-8 flex gap-4">
              <Button size="lg" asChild>
                <Link href="/signup">Start building free</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/docs">Read the docs</Link>
              </Button>
            </div>
          </div>
          <div className="relative">
            <Image
              src="/images/landing/hero-product.png"
              alt="ClawPod agent builder dashboard showing a deployed AI agent with live conversation monitoring"
              className="rounded-lg shadow-xl"
              priority
              width={800}
              height={600}
            />
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------------ */}
      {/* Features -- Asymmetric alternating layout                          */}
      {/* ------------------------------------------------------------------ */}
      <section id="features" className="py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-center text-3xl font-bold md:text-4xl">
            Everything you need to ship agents
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-center text-muted-foreground">
            From a single-agent prototype to a fleet of specialized agents
            serving millions of requests.
          </p>

          <div className="mt-16 space-y-24">
            {features.map((f, i) => (
              <div
                key={f.title}
                className={`grid items-center gap-12 lg:grid-cols-2 ${
                  i % 2 ? "lg:[&>*:first-child]:order-2" : ""
                }`}
              >
                <div>
                  <h3 className="text-2xl font-semibold">{f.title}</h3>
                  <p className="mt-4 text-muted-foreground">{f.desc}</p>
                </div>
                <Image
                  src={f.image}
                  alt={f.title}
                  className="rounded-lg"
                  width={600}
                  height={400}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------------ */}
      {/* Pricing                                                            */}
      {/* ------------------------------------------------------------------ */}
      <section id="pricing" className="bg-muted/30 py-24">
        <div className="container mx-auto max-w-5xl px-4">
          <h2 className="text-center text-3xl font-bold md:text-4xl">
            Simple, transparent pricing
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-center text-muted-foreground">
            Start free. Scale when you are ready.
          </p>

          <div className="mt-16 grid gap-8 md:grid-cols-3">
            {plans.map((plan) => (
              <Card
                key={plan.name}
                className={`flex flex-col ${
                  plan.recommended
                    ? "border-primary shadow-lg shadow-primary/10"
                    : ""
                }`}
              >
                <CardHeader>
                  {plan.recommended && (
                    <span className="mb-2 inline-block w-fit rounded-full bg-primary px-3 py-0.5 text-xs font-medium text-primary-foreground">
                      Most popular
                    </span>
                  )}
                  <CardTitle>{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    {plan.period && (
                      <span className="ml-1 text-sm text-muted-foreground">
                        {plan.period}
                      </span>
                    )}
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {plan.description}
                  </p>
                </CardHeader>

                <CardContent className="flex-1">
                  <ul className="space-y-2">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm">
                        <Check className="h-4 w-4 shrink-0 text-primary" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </CardContent>

                <CardFooter>
                  <Button
                    className="w-full"
                    variant={plan.recommended ? "default" : "outline"}
                  >
                    {plan.cta}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------------ */}
      {/* Final CTA                                                          */}
      {/* ------------------------------------------------------------------ */}
      <section className="bg-primary py-24 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold md:text-4xl">
            Your agents are waiting to be built
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-primary-foreground/80">
            Join thousands of teams already using ClawPod to ship AI-powered
            products faster.
          </p>
          <div className="mt-8">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/signup">Get started for free</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------------ */}
      {/* Footer                                                             */}
      {/* ------------------------------------------------------------------ */}
      <footer className="border-t border-border/50 py-12">
        <div className="container mx-auto flex flex-col items-center justify-between gap-4 px-4 md:flex-row">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} ClawPod. All rights reserved.
          </p>
          <nav className="flex gap-6">
            <Link
              href="/privacy"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Privacy
            </Link>
            <Link
              href="/terms"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Terms
            </Link>
            <Link
              href="/docs"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              Docs
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}
