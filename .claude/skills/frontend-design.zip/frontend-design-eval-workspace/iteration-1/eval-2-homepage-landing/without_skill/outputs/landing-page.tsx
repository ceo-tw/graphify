"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface Feature {
  title: string;
  description: string;
  bullets: string[];
  imageSrc: string;
  imageAlt: string;
}

interface PricingTier {
  name: string;
  price: string;
  period: string;
  description: string;
  features: string[];
  cta: string;
  highlighted?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Data                                                               */
/* ------------------------------------------------------------------ */

const FEATURES: Feature[] = [
  {
    title: "Deploy AI Agents in Minutes",
    description:
      "Go from idea to production-ready AI agent with our intuitive builder. Define personas, connect knowledge bases, and launch — no infrastructure expertise required.",
    bullets: [
      "Visual agent builder with real-time preview",
      "One-click deployment to managed infrastructure",
      "Built-in versioning and rollback",
    ],
    imageSrc: "/images/landing/feature-deploy.png",
    imageAlt: "ClawPod agent deployment interface showing the visual builder",
  },
  {
    title: "Monitor and Optimize Performance",
    description:
      "Get full observability into every conversation. Track latency, token usage, user satisfaction, and model quality — all from a single dashboard.",
    bullets: [
      "Real-time conversation analytics",
      "Cost tracking per agent and per session",
      "Automated quality scoring with custom rubrics",
    ],
    imageSrc: "/images/landing/feature-monitor.png",
    imageAlt: "ClawPod analytics dashboard with conversation metrics",
  },
  {
    title: "Scale with Confidence",
    description:
      "Enterprise-grade infrastructure that grows with you. Multi-region deployments, automatic scaling, and SOC 2 compliance built in from day one.",
    bullets: [
      "Auto-scaling from zero to millions of requests",
      "Multi-region failover and low-latency routing",
      "SSO, RBAC, and audit logs for your team",
    ],
    imageSrc: "/images/landing/feature-scale.png",
    imageAlt: "ClawPod infrastructure scaling visualization",
  },
];

const PRICING_TIERS: PricingTier[] = [
  {
    name: "Free",
    price: "$0",
    period: "forever",
    description: "Perfect for experimentation and personal projects.",
    features: [
      "Up to 2 agents",
      "1,000 messages / month",
      "Community support",
      "Basic analytics",
      "Shared infrastructure",
    ],
    cta: "Get Started Free",
  },
  {
    name: "Pro",
    price: "$49",
    period: "per month",
    description: "For teams building production AI products.",
    features: [
      "Unlimited agents",
      "50,000 messages / month",
      "Priority email support",
      "Advanced analytics & exports",
      "Custom domains",
      "Team collaboration (up to 10 seats)",
      "Webhook integrations",
    ],
    cta: "Start Pro Trial",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "annual billing",
    description: "For organizations with advanced security and scale needs.",
    features: [
      "Unlimited everything",
      "Dedicated infrastructure",
      "24/7 premium support & SLA",
      "SSO / SAML authentication",
      "SOC 2 & HIPAA compliance",
      "Custom model fine-tuning",
      "On-premise deployment option",
      "Dedicated solutions engineer",
    ],
    cta: "Contact Sales",
  },
];

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[var(--border)] bg-[var(--background)]/80 backdrop-blur-md">
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 text-xl font-bold tracking-tight text-[var(--foreground)]">
          <svg
            width="28"
            height="28"
            viewBox="0 0 28 28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <rect width="28" height="28" rx="6" fill="var(--primary)" />
            <path
              d="M8 10C8 8.89543 8.89543 8 10 8H18C19.1046 8 20 8.89543 20 10V18C20 19.1046 19.1046 20 18 20H10C8.89543 20 8 19.1046 8 18V10Z"
              fill="white"
              fillOpacity="0.9"
            />
            <circle cx="12" cy="13" r="1.5" fill="var(--primary)" />
            <circle cx="16" cy="13" r="1.5" fill="var(--primary)" />
          </svg>
          ClawPod
        </Link>

        {/* Desktop links */}
        <div className="hidden items-center gap-8 md:flex">
          <a href="#features" className="text-sm font-medium text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
            Features
          </a>
          <a href="#pricing" className="text-sm font-medium text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
            Pricing
          </a>
          <Link
            href="/auth/login"
            className="text-sm font-medium text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors"
          >
            Sign In
          </Link>
          <Link
            href="/auth/register"
            className="inline-flex h-9 items-center rounded-lg bg-[var(--primary)] px-4 text-sm font-medium text-[var(--primary-foreground)] shadow-sm hover:opacity-90 transition-opacity"
          >
            Get Started
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          type="button"
          className="inline-flex h-9 w-9 items-center justify-center rounded-md text-[var(--foreground)] md:hidden"
          onClick={() => setMobileOpen((o) => !o)}
          aria-label="Toggle navigation menu"
        >
          {mobileOpen ? (
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M5 5l10 10M15 5L5 15" />
            </svg>
          ) : (
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h14M3 10h14M3 14h14" />
            </svg>
          )}
        </button>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-[var(--border)] bg-[var(--background)] px-6 pb-4 pt-2 md:hidden">
          <div className="flex flex-col gap-3">
            <a href="#features" className="text-sm font-medium text-[var(--muted-foreground)]" onClick={() => setMobileOpen(false)}>
              Features
            </a>
            <a href="#pricing" className="text-sm font-medium text-[var(--muted-foreground)]" onClick={() => setMobileOpen(false)}>
              Pricing
            </a>
            <Link href="/auth/login" className="text-sm font-medium text-[var(--muted-foreground)]">
              Sign In
            </Link>
            <Link
              href="/auth/register"
              className="inline-flex h-9 w-fit items-center rounded-lg bg-[var(--primary)] px-4 text-sm font-medium text-[var(--primary-foreground)]"
            >
              Get Started
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-[var(--background)]">
      {/* Subtle gradient backdrop */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 0%, color-mix(in oklch, var(--primary) 8%, transparent), transparent)",
        }}
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-7xl px-6 pb-16 pt-20 text-center lg:pb-24 lg:pt-28">
        {/* Badge */}
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--card)] px-4 py-1.5 text-sm text-[var(--muted-foreground)] shadow-sm">
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />
          Now in General Availability
        </div>

        {/* Headline */}
        <h1 className="mx-auto max-w-4xl text-4xl font-bold leading-tight tracking-tight text-[var(--foreground)] sm:text-5xl lg:text-6xl">
          Build, Deploy &amp; Scale{" "}
          <span className="text-[var(--primary)]">AI Agents</span>{" "}
          Without the Complexity
        </h1>

        {/* Subtitle */}
        <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-[var(--muted-foreground)]">
          ClawPod is the all-in-one platform for creating intelligent AI agents.
          Design conversations, connect knowledge, and go live in minutes — not months.
        </p>

        {/* CTA buttons */}
        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link
            href="/auth/register"
            className="inline-flex h-12 items-center rounded-xl bg-[var(--primary)] px-8 text-base font-semibold text-[var(--primary-foreground)] shadow-lg shadow-[var(--primary)]/20 hover:opacity-90 transition-opacity"
          >
            Start Building for Free
          </Link>
          <a
            href="#features"
            className="inline-flex h-12 items-center rounded-xl border border-[var(--border)] bg-[var(--card)] px-8 text-base font-semibold text-[var(--foreground)] shadow-sm hover:bg-[var(--accent)] transition-colors"
          >
            See How It Works
          </a>
        </div>

        {/* Product screenshot */}
        <div className="relative mx-auto mt-16 max-w-5xl">
          <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--card)] shadow-2xl shadow-black/5">
            <Image
              src="/images/landing/hero-screenshot.png"
              alt="ClawPod platform dashboard showing agent management, conversation analytics, and deployment controls"
              width={1920}
              height={1080}
              className="h-auto w-full"
              priority
            />
          </div>
          {/* Reflection glow */}
          <div
            className="pointer-events-none absolute -bottom-8 left-1/2 h-32 w-3/4 -translate-x-1/2 blur-3xl"
            style={{ background: "color-mix(in oklch, var(--primary) 10%, transparent)" }}
            aria-hidden="true"
          />
        </div>
      </div>
    </section>
  );
}

function FeatureSection({ feature, index }: { feature: Feature; index: number }) {
  const isReversed = index % 2 !== 0;

  return (
    <div
      className={`flex flex-col items-center gap-12 lg:gap-20 ${
        isReversed ? "lg:flex-row-reverse" : "lg:flex-row"
      }`}
    >
      {/* Text */}
      <div className="flex-1 space-y-5">
        <div className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-[var(--primary)]/10 text-sm font-bold text-[var(--primary)]">
          {index + 1}
        </div>
        <h3 className="text-2xl font-bold tracking-tight text-[var(--foreground)] sm:text-3xl">
          {feature.title}
        </h3>
        <p className="text-base leading-relaxed text-[var(--muted-foreground)]">
          {feature.description}
        </p>
        <ul className="space-y-3 pt-2">
          {feature.bullets.map((bullet) => (
            <li key={bullet} className="flex items-start gap-3 text-sm text-[var(--foreground)]">
              <svg
                className="mt-0.5 h-5 w-5 shrink-0 text-[var(--primary)]"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path
                  fillRule="evenodd"
                  d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                  clipRule="evenodd"
                />
              </svg>
              {bullet}
            </li>
          ))}
        </ul>
      </div>

      {/* Image */}
      <div className="flex-1">
        <div className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--card)] shadow-lg">
          <Image
            src={feature.imageSrc}
            alt={feature.imageAlt}
            width={640}
            height={440}
            className="h-auto w-full"
          />
        </div>
      </div>
    </div>
  );
}

function FeaturesSection() {
  return (
    <section id="features" className="bg-[var(--background)] py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section header */}
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-[var(--primary)]">
            Features
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-[var(--foreground)] sm:text-4xl">
            Everything You Need to Ship AI Agents
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[var(--muted-foreground)]">
            From prototype to production, ClawPod provides the tools, infrastructure,
            and insights to build world-class AI experiences.
          </p>
        </div>

        {/* Feature rows */}
        <div className="mt-20 space-y-24 lg:space-y-32">
          {FEATURES.map((feature, i) => (
            <FeatureSection key={feature.title} feature={feature} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

function PricingCard({ tier }: { tier: PricingTier }) {
  return (
    <div
      className={`relative flex flex-col rounded-2xl border p-8 ${
        tier.highlighted
          ? "border-[var(--primary)] bg-[var(--card)] shadow-xl shadow-[var(--primary)]/5 ring-1 ring-[var(--primary)]"
          : "border-[var(--border)] bg-[var(--card)] shadow-sm"
      }`}
    >
      {tier.highlighted && (
        <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full bg-[var(--primary)] px-4 py-1 text-xs font-semibold text-[var(--primary-foreground)]">
          Most Popular
        </div>
      )}

      <div className="mb-6">
        <h3 className="text-lg font-semibold text-[var(--foreground)]">{tier.name}</h3>
        <p className="mt-1 text-sm text-[var(--muted-foreground)]">{tier.description}</p>
      </div>

      <div className="mb-8">
        <span className="text-4xl font-bold tracking-tight text-[var(--foreground)]">{tier.price}</span>
        {tier.price !== "Custom" && (
          <span className="ml-1 text-sm text-[var(--muted-foreground)]">/ {tier.period}</span>
        )}
        {tier.price === "Custom" && (
          <span className="ml-2 text-sm text-[var(--muted-foreground)]">{tier.period}</span>
        )}
      </div>

      <ul className="mb-8 flex-1 space-y-3">
        {tier.features.map((feat) => (
          <li key={feat} className="flex items-start gap-3 text-sm text-[var(--foreground)]">
            <svg
              className="mt-0.5 h-4 w-4 shrink-0 text-[var(--primary)]"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                clipRule="evenodd"
              />
            </svg>
            {feat}
          </li>
        ))}
      </ul>

      <Link
        href={tier.name === "Enterprise" ? "/contact" : "/auth/register"}
        className={`inline-flex h-11 w-full items-center justify-center rounded-lg text-sm font-semibold transition-opacity hover:opacity-90 ${
          tier.highlighted
            ? "bg-[var(--primary)] text-[var(--primary-foreground)] shadow-md shadow-[var(--primary)]/15"
            : "border border-[var(--border)] bg-[var(--card)] text-[var(--foreground)] hover:bg-[var(--accent)]"
        }`}
      >
        {tier.cta}
      </Link>
    </div>
  );
}

function PricingSection() {
  return (
    <section id="pricing" className="bg-[var(--background)] py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section header */}
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-[var(--primary)]">
            Pricing
          </p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight text-[var(--foreground)] sm:text-4xl">
            Simple, Transparent Pricing
          </h2>
          <p className="mt-4 text-base leading-relaxed text-[var(--muted-foreground)]">
            Start free and scale as you grow. No hidden fees, no surprises.
          </p>
        </div>

        {/* Pricing cards */}
        <div className="mt-16 grid gap-8 md:grid-cols-3">
          {PRICING_TIERS.map((tier) => (
            <PricingCard key={tier.name} tier={tier} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CtaSection() {
  return (
    <section className="bg-[var(--background)] py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-6">
        <div className="relative overflow-hidden rounded-2xl bg-[var(--foreground)] px-8 py-16 text-center sm:px-16 lg:py-24">
          {/* Decorative gradient */}
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(ellipse 50% 80% at 50% 100%, color-mix(in oklch, var(--primary) 20%, transparent), transparent)",
            }}
            aria-hidden="true"
          />

          <div className="relative">
            <h2 className="mx-auto max-w-2xl text-3xl font-bold tracking-tight text-[var(--background)] sm:text-4xl">
              Ready to Build Your First AI Agent?
            </h2>
            <p className="mx-auto mt-5 max-w-lg text-base leading-relaxed text-[var(--background)]/70">
              Join thousands of teams using ClawPod to create, deploy, and manage
              intelligent AI agents at scale. Get started in under 5 minutes.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                href="/auth/register"
                className="inline-flex h-12 items-center rounded-xl bg-[var(--primary)] px-8 text-base font-semibold text-[var(--primary-foreground)] shadow-lg shadow-[var(--primary)]/30 hover:opacity-90 transition-opacity"
              >
                Start Building for Free
              </Link>
              <Link
                href="/contact"
                className="inline-flex h-12 items-center rounded-xl border border-[var(--background)]/20 px-8 text-base font-semibold text-[var(--background)] hover:bg-[var(--background)]/10 transition-colors"
              >
                Talk to Sales
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-[var(--border)] bg-[var(--background)]">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 sm:flex-row">
        <p className="text-sm text-[var(--muted-foreground)]">
          &copy; {new Date().getFullYear()} ClawPod. All rights reserved.
        </p>
        <div className="flex gap-6">
          <Link href="/privacy" className="text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
            Privacy
          </Link>
          <Link href="/terms" className="text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
            Terms
          </Link>
          <Link href="/docs" className="text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
            Docs
          </Link>
        </div>
      </div>
    </footer>
  );
}

/* ------------------------------------------------------------------ */
/*  Main Landing Page                                                  */
/* ------------------------------------------------------------------ */

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[var(--background)] font-[family-name:var(--font-geist-sans)]">
      <Navbar />
      <main>
        <HeroSection />
        <FeaturesSection />
        <PricingSection />
        <CtaSection />
      </main>
      <Footer />
    </div>
  );
}
