---
name: frontend-motion
type: capability
description: "Animation and motion design guide for frontend UIs. Use when: (1) adding entrance animations, scroll effects, or transitions, (2) implementing hover/micro-interactions, (3) refining existing animations. Invoke with /frontend-motion."
allowed-tools:
  - Read
  - Grep
  - Glob
user-invocable: true
---

# Frontend Motion

Guide for implementing animations and motion in frontend UIs. Covers both project-specific MotionPreset patterns and general CSS/Framer Motion techniques.

---

## 1. Motion Philosophy

- **Communication over decoration**: Every animation answers "what changed?" or "where should I look?"
- **Respect reduced motion**: Honor `prefers-reduced-motion` media query
- **Performance budget**: 60fps or don't animate. Avoid layout thrashing
- **Consistency**: Same easing and duration across the page

---

## 2. MotionPreset Component (Project-Specific)

The admin-portal has a built-in `MotionPreset` wrapper component at `components/ui/motion-preset.tsx`.

### Import

```tsx
import { MotionPreset } from '@/components/ui/motion-preset'
```

### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `fade` | `boolean \| { initialOpacity, opacity }` | `false` | Fade in effect |
| `slide` | `boolean \| { direction, offset }` | `false` | Slide from direction |
| `zoom` | `boolean \| { initialScale, scale }` | `false` | Zoom in effect |
| `blur` | `boolean \| string` | `false` | Blur reveal effect |
| `delay` | `number` | `0` | Delay in seconds |
| `inView` | `boolean` | `true` | Trigger on viewport entry |
| `inViewOnce` | `boolean` | `true` | Only animate once |
| `component` | `MotionComponent` | `'div'` | HTML element type |
| `transition` | `Transition` | spring(200, 20) | Motion transition |

### Common Patterns

**Fade + Slide Up** (most common):
```tsx
<MotionPreset fade slide={{ direction: 'up', offset: 20 }} delay={0.1}>
  <Card>...</Card>
</MotionPreset>
```

**Staggered List**:
```tsx
{items.map((item, i) => (
  <MotionPreset key={item.id} fade slide={{ direction: 'up', offset: 20 }}
    delay={i * 0.05}>
    <ItemCard {...item} />
  </MotionPreset>
))}
```

**Zoom + Fade** (emphasis):
```tsx
<MotionPreset fade zoom={{ initialScale: 0.95 }}>
  <HeroSection />
</MotionPreset>
```

**Blur Reveal**:
```tsx
<MotionPreset fade blur="4px">
  <ContentBlock />
</MotionPreset>
```

### Default Transition

```ts
{ type: 'spring', stiffness: 200, damping: 20 }
```

Prefer MotionPreset over raw `motion.div` for consistency.

---

## 3. Entrance Sequences

### Page-Level Orchestration

One well-orchestrated load sequence per page. The parent controls timing via staggered `delay` props.

```tsx
<MotionPreset fade delay={0}>
  <PageHeader />
</MotionPreset>
<MotionPreset fade slide={{ direction: 'up', offset: 20 }} delay={0.1}>
  <FilterBar />
</MotionPreset>
<MotionPreset fade slide={{ direction: 'up', offset: 20 }} delay={0.2}>
  <DataGrid />
</MotionPreset>
```

### Stagger Increment

- Cards/list items: `delay={i * 0.05}` (50ms per item)
- Sections: `delay={i * 0.1}` (100ms per section)
- Max total stagger: ~500ms (don't make users wait)

---

## 4. Scroll-Linked Effects

MotionPreset uses `useInView` internally. For custom scroll effects:

```tsx
import { useInView, motion } from 'motion/react'

function ScrollReveal({ children }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <motion.div ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ type: 'spring', stiffness: 200, damping: 20 }}>
      {children}
    </motion.div>
  )
}
```

**Warning**: Avoid scroll-jacking (hijacking native scroll behavior).

---

## 5. Hover & Micro-Interactions

| Effect | CSS / Tailwind |
|--------|---------------|
| Subtle lift | `hover:scale-[1.02] transition-transform` |
| Background change | `hover:bg-accent transition-colors` |
| Border highlight | `hover:border-primary transition-colors` |
| Shadow on hover | `hover:shadow-md transition-shadow` |
| Focus ring | `focus-visible:ring-2 focus-visible:ring-ring/50` |

For more complex hover (e.g., card reveal):
```tsx
<motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
  transition={{ type: 'spring', stiffness: 300, damping: 20 }}>
  <Card>...</Card>
</motion.div>
```

---

## 6. Page Transitions

### AnimatePresence (Route Changes)

```tsx
import { AnimatePresence, motion } from 'motion/react'

<AnimatePresence mode="wait">
  <motion.div key={pathname}
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    transition={{ duration: 0.2 }}>
    {children}
  </motion.div>
</AnimatePresence>
```

### Skeleton-to-Content Transition

```tsx
<AnimatePresence mode="wait">
  {isLoading ? (
    <motion.div key="skeleton" exit={{ opacity: 0 }}>
      <PageSkeleton />
    </motion.div>
  ) : (
    <motion.div key="content" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <ActualContent />
    </motion.div>
  )}
</AnimatePresence>
```

---

## 7. CSS Animations (When Sufficient)

Use CSS when animation is simple and doesn't need JS control.

### Keyframes (existing in globals.css)

```css
/* Typing indicator */
@keyframes typingPulse {
  0%, 60%, 100% { opacity: 0.3; transform: scale(0.75); }
  30% { opacity: 1; transform: scale(1); }
}

/* Auth gradient */
@keyframes gradientShift {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 100%; }
  100% { background-position: 0% 50%; }
}
```

### When to Use CSS vs Framer Motion

| Use CSS | Use Framer Motion (MotionPreset) |
|---------|----------------------------------|
| Simple hover/focus transitions | Entrance sequences |
| Infinite loops (pulse, spin) | Scroll-triggered reveals |
| State-based color changes | Layout animations |
| Loading spinners | Staggered lists |
| | Exit animations (AnimatePresence) |

---

## 8. Anti-Patterns

- **Animate everything**: Overwhelming motion reduces comprehension
- **Blocking interactions**: Animations should never prevent user action
- **Competing animations**: Two things moving simultaneously
- **Decorative motion**: Movement with no communicative purpose
- **Slow animations**: Entrance > 500ms feels sluggish
- **Jank**: Animating `width`/`height`/`top`/`left` -- use `transform`/`opacity` instead
- **Ignoring reduced-motion**: Always provide `prefers-reduced-motion` fallback
