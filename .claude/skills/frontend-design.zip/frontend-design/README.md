# Frontend Design Skills

Guide for frontend developers using Claude Code to implement UIs that match design requirements.

## Quick Start: Which Skill to Use?

| I need to... | Skill | Command |
|---|---|---|
| Analyze project design system | `frontend-design-analyzer` | `/frontend-design-analyzer` |
| Build a new portal page | `frontend-app-ui` | `/frontend-app-ui` |
| Look up design tokens | `frontend-design-system` | _(library, auto-referenced)_ |
| Build a landing page / homepage | `homepage-architecture` | `/homepage-architecture` |
| Choose fonts, colors, imagery | `homepage-visual-craft` | `/homepage-visual-craft` |
| Add animations / transitions | `frontend-motion` | `/frontend-motion` |

---

## Entry Point A: Project App Design

**Workflow**: Analyze -> Decide -> Build

1. Run `/frontend-design-analyzer` to scan the project
   - Auto-extracts: colors, typography, layout tokens, components, dependencies
   - Asks you to decide: brand tone, info density, card policy, color strategy
2. Run `/frontend-app-ui` to get implementation patterns
   - Page scaffolds (List, Detail, Form, Dashboard)
   - Token mapping (Tailwind classes)
   - State handling (loading/error/empty/data)
   - Responsive breakpoints, i18n patterns

## Entry Point B: Homepage Design

**Workflow**: Structure -> Visual -> Build

1. Run `/homepage-architecture` for page structure
   - Landing page sequence: Hero -> Social Proof -> Features -> Detail -> CTA
   - Hero patterns with Tailwind code
   - Section layouts, viewport budget, copy strategy
2. Run `/homepage-visual-craft` for visual design
   - Typography selection & font pairing
   - Color palette generation
   - Imagery strategy, backgrounds
   - AI Slop checklist

## Shared

- `/frontend-motion` -- Animation patterns for both app and homepage

---

## Token Quick Reference

| Semantic | Tailwind Class | Light | Dark |
|---|---|---|---|
| Page background | `bg-background` | #F7F5F0 | #000000 |
| Card surface | `bg-card` | #FFFFFF | #181818 |
| Primary text | `text-foreground` | #1B1B1B | #FFFFFFE6 |
| Secondary text | `text-muted-foreground` | #000000CC | #FFFFFF80 |
| Primary accent | `text-primary` / `bg-primary` | #FF4D4D | #FF4D4D |
| Border | `border-border` | #EEEEEE | #333333 |
| Success | `text-success` | #00A86B | #00BA6C |
| Destructive | `text-destructive` | #0099A0 | #50D3C4 |

---

## Hard Rules (All Skills)

1. **ZERO hardcoded colors** -- token classes only (`bg-primary` not `bg-[#FF4D4D]`)
2. **All strings via i18n** -- `useTranslation()` for user-facing text
3. **'use client' only when needed** -- hooks/interactivity only
4. **Geist font only** -- no font changes in admin-portal
5. **shadcn/ui new-york style** -- use existing primitives
6. **MotionPreset for animations** -- prefer over raw `motion.div`
7. **Dark mode compliance** -- every `bg-*` must have `.dark` token counterpart

---

## Example Prompts

**New list page**:
> "Create a /portal/documents page showing a grid of document cards with search, status filter, and create button. Follow the agents page pattern."

**Add empty state**:
> "Add an empty state to the workflows page when no workflows exist. Use the EmptyState component with the Workflow icon."

**Fix dark mode**:
> "The settings page has hardcoded #f5f5f5 background. Replace with bg-background token."

**New landing page**:
> "Create a landing page for ClawPod with a product hero, feature showcase, pricing comparison, and final CTA."

**Add animations**:
> "Add entrance animations to the dashboard page. Stagger the KPI cards and chart widgets."

---

## Architecture

```
.claude/skills/
  frontend-design-analyzer/   # Entry point A: project analysis
    SKILL.md
  frontend-app-ui/            # App UI implementation guide
    SKILL.md
  frontend-design-system/     # Token & component reference (library)
    SKILL.md
  homepage-architecture/      # Entry point B: page structure
    SKILL.md
  homepage-visual-craft/      # Visual design guide
    SKILL.md
  frontend-motion/            # Shared animation guide
    SKILL.md
  frontend-design/            # This README
    README.md
```
